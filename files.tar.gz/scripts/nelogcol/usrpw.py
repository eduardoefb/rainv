#!/usr/bin/python

class usrpw:
	def __init__(self, _user, _pass):
			self._user = _user
			self._pass = _pass
		
